<?xml version="1.0" encoding="utf-8"?>
<xsl:transform version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="xml" encoding="utf-8" omit-xml-declaration="yes"/>
  <xsl:template match="/">
    <!--<xsl:comment>
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <xsl:comment/>-->
    <html>
      <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <xsl:call-template name="css-style" />
        <title>Заявка на получение в удостоверяющем центре сертификата ключа абонентского пункта</title>
      </head>
      <body bgcolor="#f1f1f1">
        <xsl:apply-templates select="Request" />
      </body>
    </html>
  </xsl:template>

  <xsl:template match="Request">
    <table align="left" width="610pt" cellspacing="2" cellpadding="3" border="0">
         <tr>
            <td width="60%"   colspan="2">&#160;</td>
            <td width="40%" class="h" align="left">[Должность]<br/>[ФИО]<br/><br/></td>
         </tr>  
         <tr>
            <td  colspan="3">
               <h2 align="center">Заявка на получение в удостоверяющем центре сертификата ключа абонентского пункта.<br/></h2>
            </td>
         </tr>
         <tr>
            <td  colspan="3">
               <p align="left">В связи с ___________________________________________________________________________,</p>
               <p align="left">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;<span style="font-size: 6pt;">предоставлением права использования СКЗИ Континент АП, плановой сменой, изменением реквизитов владельца или указать другую причину</span></p>
               <p align="left">прошу выдать сертификат ключа абонентского пункта для доступа в защищённые сети АПКШ Континент участнику информационной системы:</p> 
            </td>
         </tr>
         <xsl:call-template name="subject"/>
         <tr>
            <td  colspan="3">
               <p align="left">Паспорт:&#160;серия&#160;_______&#160;№&#160;________________&#160;выдан&#160;______________________________________<br/>_____________________________________________________&#160;&#160;дата&#160;выдачи&#160;___________________</p><br/>
               <p align="left">Приказом&#160;по&#160;организации&#160;______________________________________________________________<br/>______________________________________&#160;от&#160;"___"&#160;_______________&#160;20&#160;___&#160;г.&#160;&#160;№&#160;___________<br/>работнику&#160;предоставлены&#160;полномочия&#160;на&#160;эксплуатацию&#160;СКЗИ Континент АП(экземпляр&#160;приказа&#160;прилагается).</p><br/>
            </td>
         </tr>
         <tr>
            <td  colspan="3">
               <p align="left">Алгоритм открытого ключа: ГОСТ Р&#160;<xsl:value-of select="Param[@id='KeyAlgoritm']"/></p>
               <p align="left">Распечатка&#160;значения&#160;открытого&#160;ключа&#160;пользователя:<br/></p>
               <p align="left">
                  <span style="font-size: 10pt; font-weight: Bold;">
                     <xsl:call-template name="encoded-data">
                        <xsl:with-param name="value" select="translate(string(Param[@id='KeyData']),'&#x20;&#x9;&#xA;&#xD;','')"/>
                     </xsl:call-template>
                  </span>
               </p>
            </td>
         </tr>
          <tr>
            <td  colspan="3">
               <p align="left">Штамп открытого ключа по алгоритму ГОСТ Р&#160;<xsl:value-of select="Param[@id='HashAlgoritm']"/>:</p>
               <p align="left">
                  <span style="font-size: 10pt; font-weight: Bold;">
                     <xsl:call-template name="encoded-data">
                        <xsl:with-param name="value" select="translate(string(Param[@id='KeyHash']),'&#x20;&#x9;&#xA;&#xD;','')"/>
                     </xsl:call-template>
                  </span>
               </p>
            </td>
         </tr>
        <tr>
            <td  colspan="3">
               <p align="left">Алгоритм подписи запроса: ГОСТ Р&#160;<xsl:value-of select="Param[@id='SignAlgoritm']"/></p>
               <p align="left">Распечатка&#160;значения&#160;подписи&#160;запроса:<br/></p>
               <p align="left">
                  <span style="font-size: 10pt; font-weight: Bold;">
                     <xsl:call-template name="encoded-data">
                        <xsl:with-param name="value" select="translate(string(Param[@id='RequestHash']),'&#x20;&#x9;&#xA;&#xD;','')"/>
                     </xsl:call-template>
                  </span>
               </p>
            </td>
         </tr>
         <tr>
            <td  colspan="3">
               <p align="left">Владелец&#160;ключей&#160;ЭЦП,&#160;сформировавший&#160;запрос&#160;__________________<br/>&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;<span style="font-size: 7pt;">Подпись</span><br/>&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;"___"&#160;_______________&#160;20&#160;___&#160;г.</p>
               <p align="left"><br/><br/></p>
               <p align="left"><span style="font-size: 7pt;"></span><span style="font-size: 7pt;"></span><span style="font-size: 7pt;"></span><br/></p>
            </td>
         </tr>
      </table>
   </xsl:template>

   <!-- тело шаблона для обработки элемента 'subject' -->
   <xsl:template name="subject">
      <tr>
         <td width="30%" valign="top">Фамилия,&#160;имя,&#160;отчество</td>
         <td class="bold" width="70%" colspan="2">
           <div style="width: 420px; word-break: break-all">
             <xsl:value-of select="Param[@id='Name']"/>
           </div></td>
      </tr>
     <tr>
       <td width="30%" valign="top">Описание</td>
       <td class="bold" width="70%" colspan="2">
         <div style="width: 420px; word-break: break-all">
         <xsl:value-of select="Param[@id='Description']"/>
         </div>
       </td>
     </tr>
     <tr>
         <td width="30%" valign="top">организация</td>
         <td class="bold" width="70%" colspan="2">
           <div style="width: 420px; word-break: break-all">
             <xsl:value-of select="Param[@id='Organization']"/>
           </div>
         </td>
       </tr>
       <tr>
         <td width="30%" valign="top">должность</td>
         <td class="bold" width="70%" colspan="2"></td>
      </tr>
      <tr>
         <td width="30%" valign="top">подразделение</td>
         <td class="bold" width="70%" colspan="2">
           <div style="width: 420px; word-break: break-all">
           <xsl:value-of select="Param[@id='Department']"/>
           </div>
         </td>
      </tr>
   </xsl:template>

   <!-- тело шаблона  преобразующее исходную строку, если она есть к виду: 
           четыре символа, пробел, следующие четыре символа и т.д. до конца строки -->
   <xsl:template name="encoded-data">
      <xsl:param name="value"></xsl:param>
      <xsl:param name="count">1</xsl:param>
      <xsl:variable name="symbol">
         <xsl:choose>
            <xsl:when test="$count=8">&#160;&#160;</xsl:when>
            <xsl:otherwise>&#160;</xsl:otherwise>
         </xsl:choose>
      </xsl:variable>
      <xsl:variable name="new-count">
         <xsl:choose>
            <xsl:when test="$count=16"><xsl:value-of select="1"/></xsl:when>
            <xsl:otherwise><xsl:value-of select="$count+1"/></xsl:otherwise>
         </xsl:choose>
      </xsl:variable>
      <xsl:choose>         
         <xsl:when test="not($value='')and($value=true())">
            <xsl:value-of select="substring($value,1,2)"/><xsl:value-of select="$symbol"/>
            <xsl:choose><xsl:when test="$count=16"><br/></xsl:when><xsl:otherwise></xsl:otherwise></xsl:choose>
            <xsl:call-template name="encoded-data">
               <xsl:with-param name="value" select="substring($value,3)"/>
               <xsl:with-param name="count" select="$new-count"/>
            </xsl:call-template>
         </xsl:when>
         <xsl:otherwise></xsl:otherwise>
      </xsl:choose>
   </xsl:template>
   <!-- тело шаблона для генерирования таблицы стилей -->
   <xsl:template name="css-style">
      <style type="text/css">
         H2           { font-family: "Arial"; font-size: 11pt; font-weight: Bold; }
         
         P             { font-family: "Arial"; font-size: 10pt; font-weight: normal; font-style: normal; color: Black; margin:0cm; } 
         
         TD              { font-family: "Arial"; font-size: 10pt; font-weight: normal; color: Black; } 
         TD.h           { font-weight: normal; font-size: 10pt; }
         TD.cur        { font-weight: normal; font-size: 10pt; }
         TD.bold      { font-weight: Bold; font-size: 10pt; }
         
         LI            { font-family: "Arial"; font-size: 9pt; font-weight: normal; color: black; font-style: italic; }                  
      </style>

  </xsl:template>
</xsl:transform>