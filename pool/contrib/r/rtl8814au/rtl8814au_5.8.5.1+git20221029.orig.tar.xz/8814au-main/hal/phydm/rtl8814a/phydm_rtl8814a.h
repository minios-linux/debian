/******************************************************************************
 *
 * Copyright(c) 2007 - 2017 Realtek Corporation.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 *****************************************************************************/
#ifndef __ODM_RTL8814A_H__
#define __ODM_RTL8814A_H__
#if (RTL8814A_SUPPORT == 1)
s8 phydm_cck_rssi_8814a(struct dm_struct *dm, u16 lna_idx, u8 vga_idx);

u8 phydm_spur_nbi_setting_8814a(struct dm_struct *dm);

void phydm_hwsetting_8814a(struct dm_struct *dm);

void odm_dynamic_tx_power_8814a(void *dm_void);
#endif
#endif
