<!--

If this is a bug, please use the template below. If this is a question or general discussion topic, please start a conversation in our chat https://chat.pop-os.org/ or post on our subreddit https://reddit.com/r/pop_os - as those are the proper forums for that type of discussion.

-->


**IMPORTANT**
Please attach output of the xrandr command and ~.config/montors.xml to help diagnose the issue.


 **Distribution - (run ```cat /etc/os-release```):**
 
 
 **Related Application and/or Package Version - (run ```apt policy $PACKAGE NAME```):**



**Issue/Bug Description:**



**Steps to reproduce (if you know):**



**Expected behavior:**



**Other Notes:**
