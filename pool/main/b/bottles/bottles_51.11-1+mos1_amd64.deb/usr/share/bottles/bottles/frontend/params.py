# Application details
APP_NAME = "Bottles"
APP_NAME_LOWER = APP_NAME.lower()
APP_ID = "com.usebottles.bottles"
APP_VERSION = "51.11"
APP_ICON = "com.usebottles.bottles"
BUILD_TYPE = "prod"

# Internal settings not user editable
ANIM_DURATION = 120

# General purpose definitions
EXECUTABLE_EXTS = (".exe", ".msi", ".bat", ".lnk")

# URLs
DOC_URL = "https://docs.usebottles.com"
